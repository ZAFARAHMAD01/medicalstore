import React from 'react'

function Product() {
  return (
    <div><h1>Heading</h1></div>
  )
}

export default Product