import React from 'react'

const User = () => {
  return (
    <div>User Logged In</div>
  )
}
export default User