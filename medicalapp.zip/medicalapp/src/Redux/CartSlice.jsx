import {createSlice} from "@reduxjs/toolkit"

// const cartSlice = createSlice({
//     name:"Cart",
//     initialState:[],
//     reducers:{
//         add(state,action){
//             // state.Cart=action.payload;
//             state.push(action.payload);
            
//             console.log(action.payload);
            
//             // state.Cart.push(action.payload)
//         },
//         remove(state){
//             state.Cart = null;
//         }
//     }
// })

const cartSlice = createSlice({
    name:"Cart",
    initialState:[],
    reducers:{
        add(state,action){
            state.push(action.payload);
        },
        remove(state,action){
            console.log(action.payload);
            
            return state.filter((item)=>item.id != action.payload.id)
        }
    }
})
export const {add, remove } = cartSlice.actions;
export default cartSlice.reducer